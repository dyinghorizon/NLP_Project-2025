import os
import json
import torch
from transformers import PreTrainedTokenizerFast

class OptimizedTokenizer:
    def __init__(self, vocab_size=32000):
        self.vocab_size = vocab_size
        self.tokenizer = None
        self.special_tokens = ["<pad>", "<sos>", "<eos>", "<unk>"]
        self.special_token_ids = {
            "<pad>": 0,
            "<sos>": 1,
            "<eos>": 2,
            "<unk>": 3
        }
        
    def train(self, texts, model_prefix="tokenizer", num_samples=None):
        """Train a ByteLevelBPE tokenizer (much faster than SentencePiece)"""
        os.makedirs(model_prefix, exist_ok=True)
        
        # Sample texts to speed up training if needed
        if num_samples and len(texts) > num_samples:
            import random
            random.seed(42)
            texts = random.sample(texts, num_samples)
        
        # Write sample texts to file
        corpus_path = "corpus.txt"
        print(f"Writing {len(texts)} texts to file...")
        with open(corpus_path, 'w', encoding='utf-8') as f:
            for text in texts:
                f.write(text + '\n')
        
        # Initialize and train the tokenizer (Rust implementation - very fast)
        print("Training tokenizer (this should take minutes, not hours)...")
        from tokenizers import Tokenizer
        from tokenizers.models import BPE
        from tokenizers.trainers import BpeTrainer
        from tokenizers.pre_tokenizers import Whitespace
        
        # Create a new BPE tokenizer
        tokenizer = Tokenizer(BPE(unk_token="<unk>"))
        tokenizer.pre_tokenizer = Whitespace()
        
        # Prepare the trainer
        trainer = BpeTrainer(
            vocab_size=self.vocab_size,
            special_tokens=self.special_tokens,
            min_frequency=2
        )
        
        # Train the tokenizer
        tokenizer.train(files=[corpus_path], trainer=trainer)
        
        # Save the tokenizer
        tokenizer_path = os.path.join(model_prefix, "tokenizer.json")
        tokenizer.save(tokenizer_path)
        print(f"Tokenizer saved to {tokenizer_path}")
        
        # Load the tokenizer
        from transformers import PreTrainedTokenizerFast
        self.tokenizer = PreTrainedTokenizerFast(
            tokenizer_file=tokenizer_path,
            bos_token="<sos>",
            eos_token="<eos>",
            pad_token="<pad>",
            unk_token="<unk>"
        )
        
        # Set special token IDs explicitly
        self.tokenizer.pad_token_id = 0
        self.tokenizer.bos_token_id = 1
        self.tokenizer.eos_token_id = 2
        self.tokenizer.unk_token_id = 3
        
        # Clean up
        if os.path.exists(corpus_path):
            os.remove(corpus_path)
            
        print(f"Tokenizer training complete!")
        print(f"Vocabulary size: {self.tokenizer.vocab_size}")
        
    def encode(self, text, max_length=None, padding="max_length", truncation=True):
        if self.tokenizer is None:
            raise ValueError("Tokenizer not trained. Call train() first.")
        
        # Use the HuggingFace tokenizer
        encoding = self.tokenizer(
            text,
            add_special_tokens=True,
            max_length=max_length,
            padding=padding,
            truncation=truncation,
            return_attention_mask=True,
            return_tensors=None
        )
        
        return {
            "input_ids": encoding["input_ids"],
            "attention_mask": encoding["attention_mask"]
        }
    
    def batch_encode(self, texts, max_length=None, padding="max_length", truncation=True):
        if self.tokenizer is None:
            raise ValueError("Tokenizer not trained. Call train() first.")
        
        # Batch encode
        encodings = self.tokenizer(
            texts,
            add_special_tokens=True,
            max_length=max_length,
            padding=padding,
            truncation=truncation,
            return_attention_mask=True,
            return_tensors=None
        )
        
        return {
            "input_ids": encodings["input_ids"],
            "attention_mask": encodings["attention_mask"]
        }
    
    def decode(self, token_ids, skip_special_tokens=True):
        if self.tokenizer is None:
            raise ValueError("Tokenizer not trained. Call train() first.")
            
        if isinstance(token_ids, torch.Tensor):
            token_ids = token_ids.cpu().tolist()
            
        return self.tokenizer.decode(token_ids, skip_special_tokens=skip_special_tokens)
    
    def save(self, path):
        if self.tokenizer is None:
            raise ValueError("Tokenizer not trained. Call train() first.")
        
        os.makedirs(path, exist_ok=True)
        self.tokenizer.save_pretrained(path)
        
        # Save the special token mapping separately
        with open(os.path.join(path, "special_tokens.json"), "w") as f:
            json.dump(self.special_token_ids, f)
    
    def load(self, path):
        from transformers import PreTrainedTokenizerFast
        
        tokenizer_path = os.path.join(path, "tokenizer.json")
        if os.path.exists(tokenizer_path):
            self.tokenizer = PreTrainedTokenizerFast(
                tokenizer_file=tokenizer_path,
                bos_token="<sos>",
                eos_token="<eos>",
                pad_token="<pad>",
                unk_token="<unk>"
            )
        else:
            # Try loading as a pretrained tokenizer
            self.tokenizer = PreTrainedTokenizerFast.from_pretrained(path)
        
        # Load special token mapping if it exists
        special_tokens_path = os.path.join(path, "special_tokens.json")
        if os.path.exists(special_tokens_path):
            with open(special_tokens_path, "r") as f:
                self.special_token_ids = json.load(f)
        
        # Ensure the tokenizer has the correct special tokens
        self.tokenizer.pad_token = "<pad>"
        self.tokenizer.bos_token = "<sos>"
        self.tokenizer.eos_token = "<eos>"
        self.tokenizer.unk_token = "<unk>"
        
        # Set special token IDs explicitly
        self.tokenizer.pad_token_id = self.special_token_ids["<pad>"]
        self.tokenizer.bos_token_id = self.special_token_ids["<sos>"]
        self.tokenizer.eos_token_id = self.special_token_ids["<eos>"]
        self.tokenizer.unk_token_id = self.special_token_ids["<unk>"]
