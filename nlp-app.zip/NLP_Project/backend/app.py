from flask import Flask, request, jsonify
from flask_cors import CORS
import torch
import torch.nn.functional as F
import os
import json
import math
import logging

# Import the model and tokenizer from our modules
from model import ImprovedTransformer
from tokenizer import OptimizedTokenizer

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Global variables for model and tokenizer
model = None
tokenizer = None
device = None

def load_model():
    """Load the model and tokenizer"""
    global model, tokenizer, device
    
    # Set device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Using device: {device}")
    
    # Set paths - UPDATE THESE PATHS TO YOUR MODEL FILES
    model_path = r"D:\NLP_Project\NLP_Project\backend\model_dir\model.pt"  # Path to your model checkpoint
    tokenizer_path = r"D:\NLP_Project\NLP_Project\backend\model_dir\tokenizer"   # Path to your tokenizer directory
    
    # Load model from checkpoint
    try:
        logger.info(f"Loading model from {model_path}")
        checkpoint = torch.load(model_path, map_location=device)
        
        # Get model config from checkpoint
        if 'model_config' in checkpoint:
            config = checkpoint['model_config']
            logger.info(f"Model config: {config}")
            
            # Create model with the same architecture
            model = ImprovedTransformer(
                src_vocab_size=config['vocab_size'],
                tgt_vocab_size=config['vocab_size'],
                d_model=config['d_model'],
                num_heads=config['num_heads'],
                d_ff=config['d_ff'],
                num_layers=config['num_layers'],
                dropout=config['dropout'],
                activation=config['activation']
            ).to(device)
        else:
            # Default configuration if not found in checkpoint
            logger.warning("Model config not found in checkpoint, using default values")
            model = ImprovedTransformer(
                src_vocab_size=32000,
                tgt_vocab_size=32000,
                d_model=768,
                num_heads=12,
                d_ff=3072,
                num_layers=6,
                dropout=0.1,
                activation='gelu'
            ).to(device)
        
        # Load weights
        model.load_state_dict(checkpoint['model_state_dict'])
        model.eval()
        logger.info("Model loaded successfully")
        
        # Load tokenizer
        logger.info(f"Loading tokenizer from {tokenizer_path}")
        tokenizer = OptimizedTokenizer(vocab_size=32000)
        tokenizer.load(tokenizer_path)
        logger.info(f"Tokenizer loaded with vocabulary size: {tokenizer.tokenizer.vocab_size}")
        
        return True
    except Exception as e:
        logger.error(f"Error loading model: {str(e)}")
        return False

def interactive_summarize(
    text, 
    max_length=50, 
    temperature=0.9,  # Increased from 0.7 to encourage more diversity
    method="sampling",
    top_p=0.92,  # Slightly increased for more diverse outputs
    top_k=60,    # Increased slightly for more options
    repetition_penalty=1.5,  # New parameter to penalize repetition
    abstractive_focus=True,  # New parameter to prioritize abstractive summarization
    min_length=15,  # New parameter to ensure sufficient summary length
    complete_sentences=True  # New parameter to ensure sentences are completed
):
    """
    Generate summary with the given parameters, focusing on abstractive summarization
    with repetition avoidance and complete sentences.
    
    Args:
        text: Input text to summarize
        max_length: Maximum length of summary in tokens
        temperature: Controls randomness (higher = more creative)
        method: "greedy" or "sampling"
        top_p: Nucleus sampling threshold
        top_k: Top-k sampling threshold
        repetition_penalty: Penalty for repeating n-grams (higher = less repetition)
        abstractive_focus: Whether to emphasize abstractive over extractive summarization
        min_length: Minimum length of summary in tokens
        complete_sentences: Whether to ensure the summary ends with a complete sentence
    """
    global model, tokenizer, device
    
    # Make sure model is loaded
    if model is None or tokenizer is None:
        success = load_model()
        if not success:
            raise ValueError("Failed to load model or tokenizer")
    
    logger.info(f"Generating summary with params: max_length={max_length}, temp={temperature}, "
               f"method={method}, repetition_penalty={repetition_penalty}, "
               f"abstractive_focus={abstractive_focus}")
    
    # Truncate input if needed to avoid OOM errors
    if len(text) > 10000:
        logger.warning(f"Input text too long ({len(text)} chars), truncating to 10000 chars")
        text = text[:10000]
    
    # Add a prefix to encourage abstractive summarization if requested
    if abstractive_focus:
        prompt = "Write a concise and original summary that captures the key ideas using your own words: " + text
    else:
        prompt = text
    
    try:
        # Tokenize the input text
        encoding = tokenizer.encode(prompt, max_length=512, padding="max_length", truncation=True)
        input_ids = torch.tensor([encoding["input_ids"]]).to(device)
        
        with torch.no_grad():
            # Generate decoder start token
            decoder_input_ids = torch.tensor([[tokenizer.tokenizer.bos_token_id]]).to(device)
            
            # Create source mask
            src_mask = model.create_src_mask(input_ids)
            
            # Generate the encoding once
            encoder_output = model.encoder(input_ids, src_mask)
            
            # Track n-grams to penalize repetition
            generated_ngrams = {}
            current_length = 0
            
            # Define sentence-ending punctuation token IDs for complete sentences handling
            sentence_ending_tokens = []
            # Get the token IDs for common sentence-ending punctuation
            for punct in [".", "!", "?", ":", ";"]:
                token_id = tokenizer.encode(punct)["input_ids"][-1]  # Get the token ID for this punctuation
                sentence_ending_tokens.append(token_id)
            
            # Track if we've hit max_length but need to complete a sentence
            exceeded_max_but_completing = False
            
            # Generate tokens step by step
            for i in range(max_length * 2):  # Double max_length to give room for sentence completion
                # Create target mask
                tgt_mask = model.create_tgt_mask(decoder_input_ids)
                
                # Forward pass through decoder
                decoder_output = model.decoder(decoder_input_ids, encoder_output, src_mask, tgt_mask)
                
                # Get logits for next token
                next_token_logits = model.final_layer(decoder_output[:, -1])
                
                # Apply repetition penalty to already generated tokens
                if repetition_penalty > 1.0:
                    # Extract n-grams from current generation (2-grams and 3-grams)
                    if decoder_input_ids.size(1) >= 4:  # Only apply after generating a few tokens
                        for n in [2, 3, 4]:  # Check for 2, 3, and 4-grams
                            if decoder_input_ids.size(1) >= n:
                                # Get the last n tokens (except the most recent one, which we're predicting)
                                last_tokens = decoder_input_ids[0, -(n-1):].tolist()
                                
                                # Find tokens that would create repetitive n-grams
                                for token_id in range(next_token_logits.size(-1)):
                                    # Check if this would form a repeated n-gram
                                    potential_ngram = tuple(last_tokens + [token_id])
                                    if potential_ngram[:-1] in generated_ngrams:
                                        # Apply penalty
                                        next_token_logits[0, token_id] /= repetition_penalty
                
                # For sentence completion: If we've exceeded max_length, strongly bias toward sentence-ending tokens
                if exceeded_max_but_completing:
                    # Boost the probability of sentence-ending tokens
                    for end_token in sentence_ending_tokens:
                        next_token_logits[0, end_token] += 5.0  # Add a significant boost
                
                # Choose next token based on generation method
                if method == "greedy":
                    # Simple greedy decoding
                    next_token_id = torch.argmax(next_token_logits, dim=-1).unsqueeze(0)
                
                elif method == "sampling":
                    # Apply temperature
                    next_token_logits = next_token_logits / temperature
                    
                    # Apply top-k filtering
                    if top_k > 0:
                        indices_to_remove = next_token_logits < torch.topk(next_token_logits, top_k)[0][..., -1, None]
                        next_token_logits[indices_to_remove] = -float('Inf')
                    
                    # Apply top-p (nucleus) filtering
                    if top_p < 1.0:
                        sorted_logits, sorted_indices = torch.sort(next_token_logits, descending=True)
                        cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                        
                        # Remove tokens with cumulative probability above the threshold
                        sorted_indices_to_remove = cumulative_probs > top_p
                        # Shift the indices to the right to keep also the first token above the threshold
                        sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                        sorted_indices_to_remove[..., 0] = 0
                        
                        indices_to_remove = sorted_indices[sorted_indices_to_remove]
                        next_token_logits[0, indices_to_remove] = -float('Inf')
                    
                    # Sample from the filtered distribution
                    probs = F.softmax(next_token_logits, dim=-1)
                    next_token_id = torch.multinomial(probs, 1)
                
                # Add to sequence
                decoder_input_ids = torch.cat([decoder_input_ids, next_token_id], dim=1)
                current_length += 1
                
                # Update n-gram tracking
                if decoder_input_ids.size(1) >= 2:
                    for n in [2, 3, 4]:  # Track 2, 3, and 4-grams
                        if decoder_input_ids.size(1) >= n:
                            # Get the last n tokens
                            ngram = tuple(decoder_input_ids[0, -n:].tolist())
                            # Add to ngram counter
                            if ngram[:-1] not in generated_ngrams:
                                generated_ngrams[ngram[:-1]] = []
                            generated_ngrams[ngram[:-1]].append(ngram[-1])
                
                # Check if we need to start prioritizing sentence completion
                if current_length >= max_length and complete_sentences and not exceeded_max_but_completing:
                    exceeded_max_but_completing = True
                    logger.info("Exceeded max length but continuing to complete sentence")
                
                # Handle stopping conditions
                if next_token_id.item() == tokenizer.tokenizer.eos_token_id:
                    # Always stop on EOS token
                    break
                
                # Check for various stopping conditions
                if current_length >= min_length:
                    # If we're past max_length and found a sentence-ending token
                    if exceeded_max_but_completing and next_token_id.item() in sentence_ending_tokens:
                        break
                    
                    # If not enforcing complete sentences, stop at max_length
                    if current_length >= max_length and not complete_sentences:
                        break
                
                # Safety check - don't let generation go too long no matter what
                if i >= (max_length * 2) - 1:
                    logger.warning("Reached hard generation limit, forcing stop")
                    break
            
            # Decode the sequence
            output_ids = decoder_input_ids[0].cpu().tolist()
            summary = tokenizer.decode(output_ids, skip_special_tokens=True)
            
            # Remove the prefix if it was added and somehow included in the output
            if abstractive_focus and summary.startswith("Write a concise and original summary"):
                # Find the actual start of the summary
                summary = summary[summary.find(":")+1:].strip()
            
            return summary
    except Exception as e:
        logger.error(f"Error during summary generation: {str(e)}")
        raise

@app.route('/api/summarize', methods=['POST'])
def summarize():
    """API endpoint for summarization"""
    # Get request data
    data = request.json
    
    if not data or 'text' not in data:
        return jsonify({'error': 'No text provided'}), 400
    
    # Extract parameters with defaults
    text = data['text']
    max_length = int(data.get('maxLength', 50))
    temperature = float(data.get('temperature', 0.7))
    method = data.get('method', 'sampling')
    top_p = float(data.get('topP', 0.9))
    top_k = int(data.get('topK', 50))
    
    # Log request (truncate text for logging)
    display_text = text[:100] + "..." if len(text) > 100 else text
    logger.info(f"Received summarization request: '{display_text}'")
    
    try:
        # Generate summary
        summary = interactive_summarize(
            text=text,
            max_length=max_length,
            temperature=temperature,
            method=method,
            top_p=top_p,
            top_k=top_k
        )
        
        # Log summary (truncate for logging)
        display_summary = summary[:100] + "..." if len(summary) > 100 else summary
        logger.info(f"Generated summary: '{display_summary}'")
        
        # Return result
        return jsonify({
            'summary': summary,
            'wordCount': len(summary.split())
        })
    
    except Exception as e:
        logger.error(f"Error generating summary: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """Simple health check endpoint"""
    global model, tokenizer
    
    health_status = {
        'status': 'ok',
        'model_loaded': model is not None,
        'tokenizer_loaded': tokenizer is not None,
        'device': str(device) if device else 'not set'
    }
    
    return jsonify(health_status)

if __name__ == '__main__':
    # Load model on startup
    load_model()
    
    # Get port from environment or use default
    port = int(os.environ.get('PORT', 5000))
    
    # Run app
    logger.info(f"Starting server on port {port}")
    app.run(host='0.0.0.0', port=port, debug=False)
