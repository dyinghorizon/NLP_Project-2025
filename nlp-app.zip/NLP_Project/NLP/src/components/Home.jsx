import React, { useState, useEffect } from 'react';

const API_URL = 'http://localhost:5000/api/summarize'; // Update with your API URL

const Home = () => {
  // State for user input and parameters
  const [inputText, setInputText] = useState('');
  const [summary, setSummary] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [error, setError] = useState('');
  
  // Parameters state with updated defaults
  const [temperature, setTemperature] = useState(0.9); // Updated from 0.7
  const [maxLength, setMaxLength] = useState(50);
  const [method, setMethod] = useState('sampling');
  const [topP, setTopP] = useState(0.92); // Updated from 0.9
  const [topK, setTopK] = useState(60); // Updated from 50
  const [repetitionPenalty, setRepetitionPenalty] = useState(1.5); // New parameter
  const [abstractiveFocus, setAbstractiveFocus] = useState(true); // New parameter
  const [minLength, setMinLength] = useState(15); // New parameter
  const [completeSentences, setCompleteSentences] = useState(true); // New parameter
  
  // Call API to generate summary
  const generateSummary = async () => {
    if (!inputText.trim()) return;
    
    setIsGenerating(true);
    setError('');
    
    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: inputText,
          temperature,
          maxLength,
          method,
          topP,
          topK,
          repetitionPenalty, // New parameter
          abstractiveFocus,  // New parameter
          minLength,        // New parameter
          completeSentences  // New parameter
        }),
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error);
      }
      
      setSummary(data.summary);
      setWordCount(data.wordCount);
    } catch (err) {
      console.error('Error generating summary:', err);
      setError(`Error: ${err.message}`);
      setSummary('');
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Parameter explanations with new descriptions
  const parameterExplanations = {
    temperature: 'Controls randomness: Higher values (e.g., 0.9) make the output more diverse and creative, while lower values (e.g., 0.2) make it more focused and deterministic.',
    maxLength: 'Maximum length of the summary in words. Larger values allow for longer summaries.',
    method: 'Controls the generation strategy - "sampling" (more creative) or "greedy" (more predictable).',
    topP: 'Nucleus sampling: Only considers the most likely tokens whose cumulative probability exceeds this value. Lower values restrict creativity.',
    topK: 'Limits generation to the k most likely next tokens. Lower values make output more predictable.',
    repetitionPenalty: 'Penalizes repetition in the generated text. Higher values (>1.0) reduce phrase repetition, with 1.0 meaning no penalty.',
    abstractiveFocus: 'When enabled, prioritizes creating original wording rather than extracting phrases from the source text.',
    minLength: 'Minimum length of the summary in words. Ensures summaries have sufficient content.',
    completeSentences: 'When enabled, ensures the summary always ends with a complete sentence, even if it exceeds the maximum length slightly.'
  };

  return (
    <div className="bg-slate-50 p-6 rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-4 text-blue-700">Interactive Text Summarizer</h1>
      
      {/* Input Section */}
      <div className="mb-6">
        <label className="block text-gray-700 mb-2 font-medium">Input Text</label>
        <textarea 
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          rows={6}
          placeholder="Paste your text here to summarize..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
        />
      </div>
      
      {/* Parameters Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Temperature */}
        <div>
          <div className="flex justify-between mb-1">
            <label className="text-gray-700 font-medium">Temperature: {temperature}</label>
            <span className="text-sm text-gray-500">(0.1-1.0)</span>
          </div>
          <input 
            type="range"
            min="0.1"
            max="1.0"
            step="0.1"
            value={temperature}
            onChange={(e) => setTemperature(parseFloat(e.target.value))}
            className="w-full"
          />
          <p className="text-sm text-gray-600 mt-1">{parameterExplanations.temperature}</p>
        </div>
        
        {/* Max Length */}
        <div>
          <div className="flex justify-between mb-1">
            <label className="text-gray-700 font-medium">Max Length: {maxLength}</label>
            <span className="text-sm text-gray-500">(10-100)</span>
          </div>
          <input 
            type="range"
            min="10"
            max="100"
            step="5"
            value={maxLength}
            onChange={(e) => setMaxLength(parseInt(e.target.value))}
            className="w-full"
          />
          <p className="text-sm text-gray-600 mt-1">{parameterExplanations.maxLength}</p>
        </div>
        
        {/* Min Length - New parameter */}
        <div>
          <div className="flex justify-between mb-1">
            <label className="text-gray-700 font-medium">Min Length: {minLength}</label>
            <span className="text-sm text-gray-500">(5-50)</span>
          </div>
          <input 
            type="range"
            min="5"
            max="50"
            step="5"
            value={minLength}
            onChange={(e) => setMinLength(parseInt(e.target.value))}
            className="w-full"
          />
          <p className="text-sm text-gray-600 mt-1">{parameterExplanations.minLength}</p>
        </div>
        
        {/* Repetition Penalty - New parameter */}
        <div>
          <div className="flex justify-between mb-1">
            <label className="text-gray-700 font-medium">Repetition Penalty: {repetitionPenalty.toFixed(1)}</label>
            <span className="text-sm text-gray-500">(1.0-3.0)</span>
          </div>
          <input 
            type="range"
            min="1.0"
            max="3.0"
            step="0.1"
            value={repetitionPenalty}
            onChange={(e) => setRepetitionPenalty(parseFloat(e.target.value))}
            className="w-full"
          />
          <p className="text-sm text-gray-600 mt-1">{parameterExplanations.repetitionPenalty}</p>
        </div>
        
        {/* Abstractive Focus - New parameter */}
        <div>
          <label className="flex items-center text-gray-700 mb-1 font-medium">
            <input
              type="checkbox"
              checked={abstractiveFocus}
              onChange={(e) => setAbstractiveFocus(e.target.checked)}
              className="mr-2"
            />
            Abstractive Focus
          </label>
          <p className="text-sm text-gray-600 mt-1">{parameterExplanations.abstractiveFocus}</p>
        </div>
        
        {/* Complete Sentences - New parameter */}
        <div>
          <label className="flex items-center text-gray-700 mb-1 font-medium">
            <input
              type="checkbox"
              checked={completeSentences}
              onChange={(e) => setCompleteSentences(e.target.checked)}
              className="mr-2"
            />
            Complete Sentences
          </label>
          <p className="text-sm text-gray-600 mt-1">{parameterExplanations.completeSentences}</p>
        </div>
        
        {/* Generation Method */}
        <div>
          <label className="block text-gray-700 mb-1 font-medium">Generation Method</label>
          <select 
            value={method}
            onChange={(e) => setMethod(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="sampling">Sampling (Creative)</option>
            <option value="greedy">Greedy (Deterministic)</option>
          </select>
          <p className="text-sm text-gray-600 mt-1">{parameterExplanations.method}</p>
        </div>
        
        {/* Top-p (nucleus sampling) - Only show if sampling is selected */}
        {method === 'sampling' && (
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-gray-700 font-medium">Top-p: {topP}</label>
              <span className="text-sm text-gray-500">(0.1-1.0)</span>
            </div>
            <input 
              type="range"
              min="0.1"
              max="1.0"
              step="0.01"
              value={topP}
              onChange={(e) => setTopP(parseFloat(e.target.value))}
              className="w-full"
            />
            <p className="text-sm text-gray-600 mt-1">{parameterExplanations.topP}</p>
          </div>
        )}
        
        {/* Top-k - Only show if sampling is selected */}
        {method === 'sampling' && (
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-gray-700 font-medium">Top-k: {topK}</label>
              <span className="text-sm text-gray-500">(1-100)</span>
            </div>
            <input 
              type="range"
              min="1"
              max="100"
              step="1"
              value={topK}
              onChange={(e) => setTopK(parseInt(e.target.value))}
              className="w-full"
            />
            <p className="text-sm text-gray-600 mt-1">{parameterExplanations.topK}</p>
          </div>
        )}
      </div>
      
      {/* Generate Button */}
      <div className="mb-6">
        <button 
          onClick={generateSummary}
          disabled={isGenerating || !inputText.trim()}
          className={`px-4 py-2 rounded-md font-medium ${
            isGenerating || !inputText.trim() 
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {isGenerating ? 'Generating...' : 'Generate Summary'}
        </button>
      </div>
      
      {/* Error Message */}
      {error && (
        <div className="mb-6 p-3 bg-red-100 border border-red-300 text-red-700 rounded-md">
          {error}
        </div>
      )}
      
      {/* Output Section */}
      <div>
        <label className="block text-gray-700 mb-2 font-medium">
          Summary {wordCount > 0 && `(${wordCount} words)`}
        </label>
        <div className="border border-gray-300 rounded-md p-4 min-h-32 bg-white">
          {summary ? (
            <p>{summary}</p>
          ) : (
            <p className="text-gray-400 italic">Your summary will appear here</p>
          )}
        </div>
      </div>
      
      {/* Parameter Description Section */}
      <div className="mt-8 border-t pt-4">
        <h3 className="text-lg font-medium mb-2 text-gray-700">Parameter Guide</h3>
        <ul className="list-disc pl-5 space-y-2 text-sm text-gray-600">
          <li><span className="font-medium">Temperature:</span> {parameterExplanations.temperature}</li>
          <li><span className="font-medium">Max Length:</span> {parameterExplanations.maxLength}</li>
          <li><span className="font-medium">Min Length:</span> {parameterExplanations.minLength}</li>
          <li><span className="font-medium">Repetition Penalty:</span> {parameterExplanations.repetitionPenalty}</li>
          <li><span className="font-medium">Abstractive Focus:</span> {parameterExplanations.abstractiveFocus}</li>
          <li><span className="font-medium">Complete Sentences:</span> {parameterExplanations.completeSentences}</li>
          <li><span className="font-medium">Generation Method:</span> {parameterExplanations.method}</li>
          <li><span className="font-medium">Top-p:</span> {parameterExplanations.topP}</li>
          <li><span className="font-medium">Top-k:</span> {parameterExplanations.topK}</li>
        </ul>
      </div>
    </div>
  );
};

export default Home;